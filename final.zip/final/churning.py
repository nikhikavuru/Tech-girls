import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
app = Flask(__name__)
model = pickle.load(open('desicion.pkl', 'rb'))
from flask import Markup

@app.route('/')
def home():
    
    return render_template('index.html')

@app.route('/y_predict',methods=['POST'])
def y_predict():
    '''
    For rendering results on HTML GUI
    '''
    x_test = [float(x) for x in request.form.values()]
    
    x_test = np.array(x_test).reshape(1,18)
    prediction = model.predict(x_test)
    
    output=prediction[0]
    if output>3:
        pred=Markup("The churn risk score is: "+str(int(output))+"<br><h1 align='center' style='color:red'>Address immediately")
    else:
        pred=Markup("The churn risk score is: "+str(int(output))+"<br><h1 align='center' style='color: green'>No need to worry!")
    return render_template('index.html',output=pred)
    

@app.route('/predict_api',methods=['POST'])
def predict_api():
    '''
    For direct API calls trought request
    '''
    data = request.get_json(force=True)
    prediction = model.y_predict([np.array(list(data.values()))])

    output = prediction[0]
    return jsonify(output)


if __name__ == "__main__":
    app.run(debug=True)
